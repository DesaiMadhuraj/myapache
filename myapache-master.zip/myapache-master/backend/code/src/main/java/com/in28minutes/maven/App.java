package com.in28minutes.maven;

/**
 * Hello World test!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World Test Test Test!" );
    }

	public int calculateSomething() {
		return 0;
	}
}
